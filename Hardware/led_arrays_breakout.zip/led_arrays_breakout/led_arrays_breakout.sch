<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="9.6.2">
<drawing>
<settings>
<setting alwaysvectorfont="no"/>
<setting verticaltext="up"/>
</settings>
<grid distance="0.1" unitdist="inch" unit="inch" style="lines" multiple="1" display="no" altdistance="0.01" altunitdist="inch" altunit="inch"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="no" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="no" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="no" active="no"/>
<layer number="18" name="Vias" color="2" fill="1" visible="no" active="no"/>
<layer number="19" name="Unrouted" color="6" fill="1" visible="no" active="no"/>
<layer number="20" name="Dimension" color="15" fill="1" visible="no" active="no"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="22" name="bPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="23" name="tOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="24" name="bOrigins" color="15" fill="1" visible="no" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="26" name="bNames" color="7" fill="1" visible="no" active="no"/>
<layer number="27" name="tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="28" name="bValues" color="7" fill="1" visible="no" active="no"/>
<layer number="29" name="tStop" color="7" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="7" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="7" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="7" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="no" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="no" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="10" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="10" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="2" fill="10" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="Milling" color="3" fill="1" visible="no" active="no"/>
<layer number="47" name="Measures" color="7" fill="1" visible="no" active="no"/>
<layer number="48" name="Document" color="7" fill="1" visible="no" active="no"/>
<layer number="49" name="Reference" color="7" fill="1" visible="no" active="no"/>
<layer number="51" name="tDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="52" name="bDocu" color="7" fill="1" visible="no" active="no"/>
<layer number="88" name="SimResults" color="9" fill="1" visible="no" active="yes"/>
<layer number="89" name="SimProbes" color="9" fill="1" visible="no" active="yes"/>
<layer number="90" name="Modules" color="5" fill="1" visible="no" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="2" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="no" active="yes"/>
<layer number="98" name="Guide" color="6" fill="1" visible="no" active="yes"/>
<layer number="99" name="SpiceOrder" color="5" fill="1" visible="yes" active="yes"/>
</layers>
<schematic xreflabel="%F%N/%S.%C%R" xrefpart="/%S.%C%R">
<libraries>
<library name="SamacSys_Parts">
<description>&lt;b&gt;https://componentsearchengine.com&lt;/b&gt;&lt;p&gt;
&lt;author&gt;Created by SamacSys&lt;/author&gt;</description>
<packages>
<package name="XPEWHTL1000000E01">
<description>&lt;b&gt;XLamp XP-E LED&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.012" y="0" dx="3.3" dy="0.5" layer="1" rot="R90"/>
<smd name="2" x="1.788" y="0" dx="3.3" dy="0.5" layer="1" rot="R90"/>
<smd name="3" x="0.388" y="0" dx="3.3" dy="1.3" layer="1" rot="R90"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-1.337" y1="1.725" x2="2.113" y2="1.725" width="0.2" layer="51"/>
<wire x1="2.113" y1="1.725" x2="2.113" y2="-1.725" width="0.2" layer="51"/>
<wire x1="2.113" y1="-1.725" x2="-1.337" y2="-1.725" width="0.2" layer="51"/>
<wire x1="-1.337" y1="-1.725" x2="-1.337" y2="1.725" width="0.2" layer="51"/>
<wire x1="-3.113" y1="2.725" x2="3.113" y2="2.725" width="0.1" layer="51"/>
<wire x1="3.113" y1="2.725" x2="3.113" y2="-2.725" width="0.1" layer="51"/>
<wire x1="3.113" y1="-2.725" x2="-3.113" y2="-2.725" width="0.1" layer="51"/>
<wire x1="-3.113" y1="-2.725" x2="-3.113" y2="2.725" width="0.1" layer="51"/>
<wire x1="-2.012" y1="0.1" x2="-2.012" y2="0.1" width="0.2" layer="21"/>
<wire x1="-2.012" y1="0.1" x2="-2.012" y2="0.3" width="0.2" layer="21" curve="-180"/>
<wire x1="-2.012" y1="0.3" x2="-2.012" y2="0.3" width="0.2" layer="21"/>
<wire x1="-2.012" y1="0.3" x2="-2.012" y2="0.1" width="0.2" layer="21" curve="-180"/>
<wire x1="-0.612" y1="1.725" x2="-0.412" y2="1.725" width="0.1" layer="21"/>
<wire x1="1.188" y1="1.725" x2="1.388" y2="1.725" width="0.1" layer="21"/>
<wire x1="-0.612" y1="-1.725" x2="-0.412" y2="-1.725" width="0.1" layer="21"/>
<wire x1="1.188" y1="-1.725" x2="1.388" y2="-1.725" width="0.1" layer="21"/>
</package>
<package name="XPEBPAL1000000B01">
<description>&lt;b&gt;XPEBPA-L1-0000-00B01-1&lt;/b&gt;&lt;br&gt;
</description>
<smd name="1" x="-1.4" y="0" dx="3.3" dy="0.5" layer="1" rot="R90"/>
<smd name="2" x="1.4" y="0" dx="3.3" dy="0.5" layer="1" rot="R90"/>
<smd name="3" x="0" y="0" dx="3.3" dy="1.3" layer="1" rot="R90"/>
<text x="0" y="0" size="1.27" layer="25" align="center">&gt;NAME</text>
<text x="0" y="0" size="1.27" layer="27" align="center">&gt;VALUE</text>
<wire x1="-1.725" y1="-1.725" x2="1.725" y2="-1.725" width="0.1" layer="51"/>
<wire x1="1.725" y1="-1.725" x2="1.725" y2="1.725" width="0.1" layer="51"/>
<wire x1="1.725" y1="1.725" x2="-1.725" y2="1.725" width="0.1" layer="51"/>
<wire x1="-1.725" y1="1.725" x2="-1.725" y2="-1.725" width="0.1" layer="51"/>
<wire x1="-2.725" y1="2.725" x2="2.725" y2="2.725" width="0.1" layer="51"/>
<wire x1="2.725" y1="2.725" x2="2.725" y2="-2.725" width="0.1" layer="51"/>
<wire x1="2.725" y1="-2.725" x2="-2.725" y2="-2.725" width="0.1" layer="51"/>
<wire x1="-2.725" y1="-2.725" x2="-2.725" y2="2.725" width="0.1" layer="51"/>
<wire x1="-2.3" y1="0" x2="-2.3" y2="0" width="0.1" layer="21"/>
<wire x1="-2.3" y1="0" x2="-2.2" y2="0" width="0.1" layer="21" curve="180"/>
<wire x1="-2.2" y1="0" x2="-2.2" y2="0" width="0.1" layer="21"/>
<wire x1="-2.2" y1="0" x2="-2.3" y2="0" width="0.1" layer="21" curve="180"/>
</package>
</packages>
<symbols>
<symbol name="XPEBWT-U1-R250-009E7">
<wire x1="5.08" y1="7.62" x2="15.24" y2="7.62" width="0.254" layer="94"/>
<wire x1="15.24" y1="-2.54" x2="15.24" y2="7.62" width="0.254" layer="94"/>
<wire x1="15.24" y1="-2.54" x2="5.08" y2="-2.54" width="0.254" layer="94"/>
<wire x1="5.08" y1="7.62" x2="5.08" y2="-2.54" width="0.254" layer="94"/>
<text x="16.51" y="12.7" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="16.51" y="10.16" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="K" x="0" y="0" length="middle"/>
<pin name="A" x="20.32" y="0" length="middle" rot="R180"/>
<pin name="EP" x="10.16" y="12.7" length="middle" rot="R270"/>
</symbol>
<symbol name="XPEBPA-L1-0000-00B01">
<wire x1="5.08" y1="2.54" x2="15.24" y2="2.54" width="0.254" layer="94"/>
<wire x1="15.24" y1="-7.62" x2="15.24" y2="2.54" width="0.254" layer="94"/>
<wire x1="15.24" y1="-7.62" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<wire x1="5.08" y1="2.54" x2="5.08" y2="-7.62" width="0.254" layer="94"/>
<text x="16.51" y="7.62" size="1.778" layer="95" align="center-left">&gt;NAME</text>
<text x="16.51" y="5.08" size="1.778" layer="96" align="center-left">&gt;VALUE</text>
<pin name="K" x="0" y="0" length="middle"/>
<pin name="A" x="0" y="-5.08" length="middle"/>
<pin name="EP" x="0" y="-2.54" length="middle"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="XPEBWT-U1-R250-009E7" prefix="LED">
<description>&lt;b&gt;Cree XPEBWT-U1-R250-009E7, XLamp XP-E2 Series White High-Power LED, 3000K,, Square Lens SMD Package&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://www.cree.com/led-components/media/documents/XLampXPE2.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="XPEBWT-U1-R250-009E7" x="0" y="0"/>
</gates>
<devices>
<device name="" package="XPEWHTL1000000E01">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="EP" pad="3"/>
<connect gate="G$1" pin="K" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="ARROW_PART_NUMBER" value="XPEBWT-U1-R250-009E7" constant="no"/>
<attribute name="ARROW_PRICE-STOCK" value="https://www.arrow.com/en/products/xpebwt-u1-r250-009e7/cree" constant="no"/>
<attribute name="DESCRIPTION" value="Cree XPEBWT-U1-R250-009E7, XLamp XP-E2 Series White High-Power LED, 3000K,, Square Lens SMD Package" constant="no"/>
<attribute name="HEIGHT" value="mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Wolfspeed" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="XPEBWT-U1-R250-009E7" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="941-XPEBWTU1R2509E7" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.com/Search/Refine.aspx?Keyword=941-XPEBWTU1R2509E7" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="XPEBPA-L1-0000-00B01" prefix="LED">
<description>&lt;b&gt;Cree XPEBPA-L1-0000-00B01, XLamp XP-E2 Series PC Amber LED, 595 nm, Clear, Dome Lens SMD Package&lt;/b&gt;&lt;p&gt;
Source: &lt;a href="https://cree-led.com/media/documents/XLampXPE2.pdf"&gt; Datasheet &lt;/a&gt;</description>
<gates>
<gate name="G$1" symbol="XPEBPA-L1-0000-00B01" x="0" y="0"/>
</gates>
<devices>
<device name="" package="XPEBPAL1000000B01">
<connects>
<connect gate="G$1" pin="A" pad="2"/>
<connect gate="G$1" pin="EP" pad="3"/>
<connect gate="G$1" pin="K" pad="1"/>
</connects>
<technologies>
<technology name="">
<attribute name="ARROW_PART_NUMBER" value="" constant="no"/>
<attribute name="ARROW_PRICE-STOCK" value="" constant="no"/>
<attribute name="DESCRIPTION" value="Cree XPEBPA-L1-0000-00B01, XLamp XP-E2 Series PC Amber LED, 595 nm, Clear, Dome Lens SMD Package" constant="no"/>
<attribute name="HEIGHT" value="2.53mm" constant="no"/>
<attribute name="MANUFACTURER_NAME" value="Wolfspeed" constant="no"/>
<attribute name="MANUFACTURER_PART_NUMBER" value="XPEBPA-L1-0000-00B01" constant="no"/>
<attribute name="MOUSER_PART_NUMBER" value="941-XPEBPAL10000B01" constant="no"/>
<attribute name="MOUSER_PRICE-STOCK" value="https://www.mouser.co.uk/ProductDetail/Cree-Inc/XPEBPA-L1-0000-00B01?qs=odi%2FggezlBvEJ61b2kTHEA%3D%3D" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="con-phoenix-254" urn="urn:adsk.eagle:library:172">
<description>&lt;b&gt;Phoenix Connectors&lt;/b&gt;&lt;p&gt;
Grid 2.54 mm&lt;p&gt;
&lt;author&gt;Created by librarian@cadsoft.de&lt;/author&gt;</description>
<packages>
<package name="3POL254" urn="urn:adsk.eagle:footprint:9306/1" library_version="2">
<description>&lt;b&gt;PHOENIX CONNECTOR&lt;/b&gt;</description>
<wire x1="-3.94" y1="-1.45" x2="3.94" y2="-1.45" width="0.254" layer="21"/>
<wire x1="3.94" y1="-1.45" x2="3.94" y2="1.45" width="0.254" layer="21"/>
<wire x1="3.94" y1="1.45" x2="-3.94" y2="1.45" width="0.254" layer="21"/>
<wire x1="-3.94" y1="1.45" x2="-3.94" y2="-1.45" width="0.254" layer="21"/>
<wire x1="-3.83" y1="1.1" x2="3.83" y2="1.1" width="0.1524" layer="21"/>
<wire x1="-3.175" y1="-0.508" x2="-2.032" y2="0.635" width="0.1524" layer="51"/>
<wire x1="-0.762" y1="-0.254" x2="0.762" y2="0.127" width="0.1524" layer="51"/>
<wire x1="2.032" y1="0.635" x2="3.048" y2="-0.635" width="0.1524" layer="51"/>
<circle x="-2.54" y="0" radius="0.889" width="0.1524" layer="51"/>
<circle x="0" y="0" radius="0.889" width="0.1524" layer="51"/>
<circle x="2.54" y="0" radius="0.889" width="0.1524" layer="51"/>
<pad name="1" x="-2.54" y="0" drill="1.2" shape="long" rot="R90"/>
<pad name="2" x="0" y="0" drill="1.2" shape="long" rot="R90"/>
<pad name="3" x="2.54" y="0" drill="1.2" shape="long" rot="R90"/>
<text x="-4.064" y="1.778" size="1.27" layer="25">&gt;NAME</text>
<text x="-4.064" y="-3.048" size="1.27" layer="27">&gt;VALUE</text>
</package>
</packages>
<packages3d>
<package3d name="3POL254" urn="urn:adsk.eagle:package:9316/1" type="box" library_version="2">
<description>PHOENIX CONNECTOR</description>
<packageinstances>
<packageinstance name="3POL254"/>
</packageinstances>
</package3d>
</packages3d>
<symbols>
<symbol name="SKB" urn="urn:adsk.eagle:symbol:9303/1" library_version="2">
<wire x1="2.032" y1="0.762" x2="0.508" y2="-0.762" width="0.254" layer="94"/>
<circle x="1.27" y="0" radius="1.27" width="0.254" layer="94"/>
<text x="3.556" y="-0.635" size="1.778" layer="95">&gt;NAME</text>
<pin name="1" x="-2.54" y="0" visible="pad" length="short" direction="pas"/>
</symbol>
<symbol name="SKBV" urn="urn:adsk.eagle:symbol:9304/1" library_version="2">
<wire x1="2.032" y1="0.762" x2="0.508" y2="-0.762" width="0.254" layer="94"/>
<circle x="1.27" y="0" radius="1.27" width="0.254" layer="94"/>
<text x="3.556" y="-0.635" size="1.778" layer="95">&gt;NAME</text>
<text x="-1.016" y="-3.302" size="1.778" layer="96">&gt;VALUE</text>
<pin name="1" x="-2.54" y="0" visible="pad" length="short" direction="pas"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="MPT3" urn="urn:adsk.eagle:component:9324/2" prefix="X" uservalue="yes" library_version="2">
<description>&lt;b&gt;PHOENIX CONNECTOR&lt;/b&gt;</description>
<gates>
<gate name="-1" symbol="SKB" x="0" y="5.08" addlevel="always"/>
<gate name="-2" symbol="SKB" x="0" y="0" addlevel="always"/>
<gate name="-3" symbol="SKBV" x="0" y="-5.08" addlevel="always"/>
</gates>
<devices>
<device name="" package="3POL254">
<connects>
<connect gate="-1" pin="1" pad="1"/>
<connect gate="-2" pin="1" pad="2"/>
<connect gate="-3" pin="1" pad="3"/>
</connects>
<package3dinstances>
<package3dinstance package3d_urn="urn:adsk.eagle:package:9316/1"/>
</package3dinstances>
<technologies>
<technology name="">
<attribute name="MF" value="" constant="no"/>
<attribute name="MPN" value="" constant="no"/>
<attribute name="OC_FARNELL" value="unknown" constant="no"/>
<attribute name="OC_NEWARK" value="unknown" constant="no"/>
<attribute name="POPULARITY" value="3" constant="no"/>
</technology>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0" drill="0">
</class>
</classes>
<parts>
<part name="DW1" library="SamacSys_Parts" deviceset="XPEBWT-U1-R250-009E7" device=""/>
<part name="DW2" library="SamacSys_Parts" deviceset="XPEBWT-U1-R250-009E7" device=""/>
<part name="DW3" library="SamacSys_Parts" deviceset="XPEBWT-U1-R250-009E7" device=""/>
<part name="DW4" library="SamacSys_Parts" deviceset="XPEBWT-U1-R250-009E7" device=""/>
<part name="DW5" library="SamacSys_Parts" deviceset="XPEBWT-U1-R250-009E7" device=""/>
<part name="X1" library="con-phoenix-254" library_urn="urn:adsk.eagle:library:172" deviceset="MPT3" device="" package3d_urn="urn:adsk.eagle:package:9316/1"/>
<part name="DA1" library="SamacSys_Parts" deviceset="XPEBPA-L1-0000-00B01" device=""/>
<part name="DA2" library="SamacSys_Parts" deviceset="XPEBPA-L1-0000-00B01" device=""/>
<part name="DA3" library="SamacSys_Parts" deviceset="XPEBPA-L1-0000-00B01" device=""/>
<part name="DA4" library="SamacSys_Parts" deviceset="XPEBPA-L1-0000-00B01" device=""/>
<part name="DA5" library="SamacSys_Parts" deviceset="XPEBPA-L1-0000-00B01" device=""/>
</parts>
<sheets>
<sheet>
<plain>
</plain>
<instances>
<instance part="DW1" gate="G$1" x="84.431234375" y="29.865425" smashed="yes" rot="R180">
<attribute name="NAME" x="67.921234375" y="17.165425" size="1.778" layer="95" rot="R180" align="center-left"/>
<attribute name="VALUE" x="67.921234375" y="19.705425" size="1.778" layer="96" rot="R180" align="center-left"/>
</instance>
<instance part="DW2" gate="G$1" x="83.82" y="50.8" smashed="yes" rot="R180">
<attribute name="NAME" x="67.31" y="38.1" size="1.778" layer="95" rot="R180" align="center-left"/>
<attribute name="VALUE" x="67.31" y="40.64" size="1.778" layer="96" rot="R180" align="center-left"/>
</instance>
<instance part="DW3" gate="G$1" x="83.82" y="71.12" smashed="yes" rot="R180">
<attribute name="NAME" x="67.31" y="58.42" size="1.778" layer="95" rot="R180" align="center-left"/>
<attribute name="VALUE" x="67.31" y="60.96" size="1.778" layer="96" rot="R180" align="center-left"/>
</instance>
<instance part="DW4" gate="G$1" x="83.82" y="91.44" smashed="yes" rot="R180">
<attribute name="NAME" x="67.31" y="78.74" size="1.778" layer="95" rot="R180" align="center-left"/>
<attribute name="VALUE" x="67.31" y="81.28" size="1.778" layer="96" rot="R180" align="center-left"/>
</instance>
<instance part="DW5" gate="G$1" x="83.82" y="111.76" smashed="yes" rot="R180">
<attribute name="NAME" x="67.31" y="99.06" size="1.778" layer="95" rot="R180" align="center-left"/>
<attribute name="VALUE" x="67.31" y="101.6" size="1.778" layer="96" rot="R180" align="center-left"/>
</instance>
<instance part="X1" gate="-1" x="40.64" y="7.62" smashed="yes" rot="R270">
<attribute name="NAME" x="40.005" y="4.064" size="1.778" layer="95" rot="R270"/>
</instance>
<instance part="X1" gate="-2" x="35.56" y="7.62" smashed="yes" rot="R270">
<attribute name="NAME" x="34.925" y="4.064" size="1.778" layer="95" rot="R270"/>
</instance>
<instance part="X1" gate="-3" x="30.48" y="7.62" smashed="yes" rot="R270">
<attribute name="NAME" x="29.845" y="4.064" size="1.778" layer="95" rot="R270"/>
<attribute name="VALUE" x="27.178" y="8.636" size="1.778" layer="96" rot="R270"/>
</instance>
<instance part="DA1" gate="G$1" x="109.22" y="106.68" smashed="yes" rot="R180">
<attribute name="NAME" x="92.71" y="99.06" size="1.778" layer="95" rot="R180" align="center-left"/>
<attribute name="VALUE" x="92.71" y="101.6" size="1.778" layer="96" rot="R180" align="center-left"/>
</instance>
<instance part="DA2" gate="G$1" x="109.22" y="86.36" smashed="yes" rot="R180">
<attribute name="NAME" x="92.71" y="78.74" size="1.778" layer="95" rot="R180" align="center-left"/>
<attribute name="VALUE" x="92.71" y="81.28" size="1.778" layer="96" rot="R180" align="center-left"/>
</instance>
<instance part="DA3" gate="G$1" x="109.22" y="66.04" smashed="yes" rot="R180">
<attribute name="NAME" x="92.71" y="58.42" size="1.778" layer="95" rot="R180" align="center-left"/>
<attribute name="VALUE" x="92.71" y="60.96" size="1.778" layer="96" rot="R180" align="center-left"/>
</instance>
<instance part="DA4" gate="G$1" x="109.22" y="45.72" smashed="yes" rot="R180">
<attribute name="NAME" x="92.71" y="38.1" size="1.778" layer="95" rot="R180" align="center-left"/>
<attribute name="VALUE" x="92.71" y="40.64" size="1.778" layer="96" rot="R180" align="center-left"/>
</instance>
<instance part="DA5" gate="G$1" x="109.22" y="25.4" smashed="yes" rot="R180">
<attribute name="NAME" x="92.71" y="17.78" size="1.778" layer="95" rot="R180" align="center-left"/>
<attribute name="VALUE" x="92.71" y="20.32" size="1.778" layer="96" rot="R180" align="center-left"/>
</instance>
</instances>
<busses>
</busses>
<nets>
<net name="N$9" class="0">
<segment>
<wire x1="22.86" y1="119.38" x2="63.5" y2="119.38" width="0.1524" layer="91"/>
<pinref part="DW5" gate="G$1" pin="A"/>
<wire x1="63.5" y1="119.38" x2="109.22" y2="119.38" width="0.1524" layer="91"/>
<wire x1="63.5" y1="119.38" x2="63.5" y2="111.76" width="0.1524" layer="91"/>
<junction x="63.5" y="119.38"/>
<pinref part="X1" gate="-3" pin="1"/>
<wire x1="22.86" y1="119.38" x2="22.86" y2="10.16" width="0.1524" layer="91"/>
<wire x1="22.86" y1="10.16" x2="30.48" y2="10.16" width="0.1524" layer="91"/>
<pinref part="DA1" gate="G$1" pin="A"/>
<wire x1="109.22" y1="111.76" x2="109.22" y2="119.38" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$1" class="0">
<segment>
<pinref part="DW5" gate="G$1" pin="K"/>
<wire x1="83.82" y1="111.76" x2="83.82" y2="96.52" width="0.1524" layer="91"/>
<wire x1="83.82" y1="96.52" x2="63.5" y2="96.52" width="0.1524" layer="91"/>
<pinref part="DW4" gate="G$1" pin="A"/>
<wire x1="63.5" y1="96.52" x2="63.5" y2="91.44" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$2" class="0">
<segment>
<pinref part="DW4" gate="G$1" pin="K"/>
<wire x1="83.82" y1="91.44" x2="83.82" y2="76.2" width="0.1524" layer="91"/>
<wire x1="83.82" y1="76.2" x2="63.5" y2="76.2" width="0.1524" layer="91"/>
<pinref part="DW3" gate="G$1" pin="A"/>
<wire x1="63.5" y1="76.2" x2="63.5" y2="71.12" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$3" class="0">
<segment>
<pinref part="DW3" gate="G$1" pin="K"/>
<wire x1="83.82" y1="71.12" x2="83.82" y2="55.88" width="0.1524" layer="91"/>
<wire x1="83.82" y1="55.88" x2="63.5" y2="55.88" width="0.1524" layer="91"/>
<pinref part="DW2" gate="G$1" pin="A"/>
<wire x1="63.5" y1="55.88" x2="63.5" y2="50.8" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$4" class="0">
<segment>
<pinref part="DW2" gate="G$1" pin="K"/>
<wire x1="83.82" y1="50.8" x2="83.82" y2="35.56" width="0.1524" layer="91"/>
<wire x1="83.82" y1="35.56" x2="63.5" y2="35.56" width="0.1524" layer="91"/>
<wire x1="63.5" y1="35.56" x2="63.5" y2="29.865425" width="0.1524" layer="91"/>
<pinref part="DW1" gate="G$1" pin="A"/>
<wire x1="63.5" y1="29.865425" x2="64.111234375" y2="29.865425" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$5" class="0">
<segment>
<pinref part="X1" gate="-2" pin="1"/>
<wire x1="35.56" y1="10.16" x2="35.56" y2="12.7" width="0.1524" layer="91"/>
<wire x1="35.56" y1="12.7" x2="109.22" y2="12.7" width="0.1524" layer="91"/>
<pinref part="DA5" gate="G$1" pin="K"/>
<wire x1="109.22" y1="25.4" x2="109.22" y2="12.7" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$6" class="0">
<segment>
<pinref part="X1" gate="-1" pin="1"/>
<wire x1="40.64" y1="10.16" x2="73.66" y2="10.16" width="0.1524" layer="91"/>
<pinref part="DW1" gate="G$1" pin="K"/>
<wire x1="73.66" y1="10.16" x2="74.271234375" y2="10.16" width="0.1524" layer="91"/>
<wire x1="84.431234375" y1="29.865425" x2="84.431234375" y2="10.16" width="0.1524" layer="91"/>
<wire x1="84.431234375" y1="10.16" x2="74.271234375" y2="10.16" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$24" class="0">
<segment>
<pinref part="DA1" gate="G$1" pin="K"/>
<pinref part="DA2" gate="G$1" pin="A"/>
<wire x1="109.22" y1="106.68" x2="109.22" y2="91.44" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$25" class="0">
<segment>
<pinref part="DA3" gate="G$1" pin="A"/>
<pinref part="DA2" gate="G$1" pin="K"/>
<wire x1="109.22" y1="71.12" x2="109.22" y2="86.36" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$26" class="0">
<segment>
<pinref part="DA3" gate="G$1" pin="K"/>
<pinref part="DA4" gate="G$1" pin="A"/>
<wire x1="109.22" y1="66.04" x2="109.22" y2="50.8" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$27" class="0">
<segment>
<pinref part="DA4" gate="G$1" pin="K"/>
<pinref part="DA5" gate="G$1" pin="A"/>
<wire x1="109.22" y1="45.72" x2="109.22" y2="30.48" width="0.1524" layer="91"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
</schematic>
</drawing>
<compatibility>
<note version="8.2" severity="warning">
Since Version 8.2, EAGLE supports online libraries. The ids
of those online libraries will not be understood (or retained)
with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports URNs for individual library
assets (packages, symbols, and devices). The URNs of those assets
will not be understood (or retained) with this version.
</note>
<note version="8.3" severity="warning">
Since Version 8.3, EAGLE supports the association of 3D packages
with devices in libraries, schematics, and board files. Those 3D
packages will not be understood (or retained) with this version.
</note>
</compatibility>
</eagle>
